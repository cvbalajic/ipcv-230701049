# ─── utils.py ───────────────────────────────────────────────────────────────
# Utility Functions for HSV + Kalman Tracker Project
# ─────────────────────────────────────────────────────────────────────────────

import cv2
import numpy as np
import os
import time


def create_info_panel(frame, info_dict, panel_width=280):
    """
    Create a side information panel showing tracker statistics.

    Args:
        frame: Current video frame
        info_dict: Dictionary of key-value pairs to display
        panel_width: Width of the info panel in pixels

    Returns:
        combined: Frame with info panel on the right
    """
    h, w = frame.shape[:2]
    panel = np.zeros((h, panel_width, 3), dtype=np.uint8)
    panel[:] = (40, 40, 40)  # Dark grey background

    # Title
    cv2.putText(panel, "TRACKER INFO", (10, 25),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 255), 2)
    cv2.line(panel, (10, 35), (panel_width - 10, 35), (100, 100, 100), 1)

    y_offset = 60
    for key, value in info_dict.items():
        cv2.putText(panel, f"{key}:", (10, y_offset),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (180, 180, 180), 1)
        cv2.putText(panel, str(value), (130, y_offset),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        y_offset += 25

    combined = np.hstack([frame, panel])
    return combined


class FPSCounter:
    """Simple FPS counter for real-time performance measurement."""

    def __init__(self, avg_frames=30):
        self.avg_frames = avg_frames
        self.times = []
        self.fps = 0.0

    def tick(self):
        """Call this every frame."""
        self.times.append(time.time())
        if len(self.times) > self.avg_frames:
            self.times.pop(0)

        if len(self.times) >= 2:
            dt = self.times[-1] - self.times[0]
            if dt > 0:
                self.fps = (len(self.times) - 1) / dt

    def get_fps(self):
        return round(self.fps, 1)


def save_frame_with_timestamp(frame, output_dir="output", prefix="frame"):
    """Save a frame with a timestamp in the filename."""
    os.makedirs(output_dir, exist_ok=True)
    timestamp = int(time.time() * 1000)
    path = os.path.join(output_dir, f"{prefix}_{timestamp}.jpg")
    cv2.imwrite(path, frame)
    return path


def overlay_mask(frame, mask, color=(0, 255, 0), alpha=0.3):
    """Overlay a binary mask on the frame with transparency."""
    overlay = frame.copy()
    mask_bool = mask > 127
    overlay[mask_bool] = (
        (1 - alpha) * overlay[mask_bool] +
        alpha * np.array(color, dtype=np.float32)
    ).astype(np.uint8)
    return overlay


def draw_hsv_histogram(hsv_img, mask=None):
    """
    Draw H and S channel histograms for HSV analysis.
    Returns a BGR image of the histogram plot.
    """
    hist_h = cv2.calcHist([hsv_img], [0], mask, [180], [0, 180])
    hist_s = cv2.calcHist([hsv_img], [1], mask, [256], [0, 256])

    # Create histogram image
    hist_img = np.zeros((200, 360, 3), dtype=np.uint8)
    hist_img[:] = (30, 30, 30)

    # Normalize
    cv2.normalize(hist_h, hist_h, 0, 180, cv2.NORM_MINMAX)
    cv2.normalize(hist_s, hist_s, 0, 180, cv2.NORM_MINMAX)

    # Draw H histogram (left half)
    for i in range(180):
        val = int(hist_h[i])
        cv2.line(hist_img, (i, 199), (i, 199 - val), (0, 150, 255), 1)

    # Draw S histogram (right half)
    for i in range(256):
        val = int(hist_s[i])
        x = 180 + int(i * 180 / 256)
        cv2.line(hist_img, (x, 199), (x, 199 - val), (255, 150, 0), 1)

    cv2.putText(hist_img, "Hue", (70, 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 150, 255), 1)
    cv2.putText(hist_img, "Saturation", (240, 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 150, 0), 1)

    return hist_img
