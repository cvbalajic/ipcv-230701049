# ─── kalman_tracker.py ──────────────────────────────────────────────────────
# Kalman Filter Tracker for Skin Region Tracking
# ─────────────────────────────────────────────────────────────────────────────

import cv2
import numpy as np


class KalmanSkinTracker:
    """
    Kalman Filter-based tracker for skin regions detected via HSV thresholding.

    State vector: [x, y, vx, vy]  — position and velocity of centroid
    Measurement:  [x, y]          — observed centroid from skin detection

    The Kalman filter smooths noisy detections and predicts position when
    the skin region is temporarily lost (occlusion handling).
    """

    def __init__(self, process_noise=1e-2, measurement_noise=1e-1):
        """
        Initialise the Kalman filter.

        Args:
            process_noise: Controls how much the model trusts the motion model
            measurement_noise: Controls how much the model trusts measurements
        """
        # 4 state variables (x, y, vx, vy), 2 measurement variables (x, y)
        self.kf = cv2.KalmanFilter(4, 2)

        # ── Transition matrix (constant velocity model) ──
        # x_new = x + vx * dt
        # y_new = y + vy * dt
        # vx_new = vx
        # vy_new = vy
        self.kf.transitionMatrix = np.array([
            [1, 0, 1, 0],
            [0, 1, 0, 1],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ], dtype=np.float32)

        # ── Measurement matrix ──
        # We only observe position (x, y), not velocity
        self.kf.measurementMatrix = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0]
        ], dtype=np.float32)

        # ── Process noise covariance ──
        self.kf.processNoiseCov = np.eye(4, dtype=np.float32) * process_noise

        # ── Measurement noise covariance ──
        self.kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * measurement_noise

        # ── Error covariance (initial) ──
        self.kf.errorCovPost = np.eye(4, dtype=np.float32)

        # Tracking state
        self.initialized = False
        self.frames_lost = 0
        self.max_lost_frames = 15  # Max frames to predict without measurement
        self.track_history = []    # History of tracked positions
        self.predicted_bbox = None

    def initialize(self, cx, cy):
        """Initialize the Kalman filter state with a first detection."""
        self.kf.statePost = np.array(
            [[np.float32(cx)],
             [np.float32(cy)],
             [np.float32(0)],
             [np.float32(0)]]
        )
        self.initialized = True
        self.frames_lost = 0
        self.track_history = [(int(cx), int(cy))]

    def predict(self):
        """
        Predict the next position using the motion model.
        Returns predicted (x, y).
        """
        if not self.initialized:
            return None

        prediction = self.kf.predict()
        px, py = int(prediction[0, 0]), int(prediction[1, 0])
        return (px, py)

    def update(self, cx, cy):
        """
        Correct the Kalman state with a new measurement.

        Args:
            cx, cy: Observed centroid of the skin region
        """
        measurement = np.array(
            [[np.float32(cx)],
             [np.float32(cy)]]
        )
        self.kf.correct(measurement)
        self.frames_lost = 0

        # Store in history (keep last 50 points for trajectory)
        pos = (int(cx), int(cy))
        self.track_history.append(pos)
        if len(self.track_history) > 50:
            self.track_history.pop(0)

    def track(self, detection_bbox, detection_centroid):
        """
        Main tracking function: predict → update (if detection available).

        Args:
            detection_bbox: (x, y, w, h) from skin detector, or None
            detection_centroid: (cx, cy) from skin detector, or None

        Returns:
            tracked_position: (x, y) — smoothed or predicted centroid
            tracked_bbox: (x, y, w, h) — estimated bounding box
            is_predicted: True if using prediction only (no measurement)
        """
        if not self.initialized:
            if detection_centroid is not None:
                self.initialize(*detection_centroid)
                self.predicted_bbox = detection_bbox
                return detection_centroid, detection_bbox, False
            else:
                return None, None, False

        # Step 1: Predict
        predicted_pos = self.predict()

        # Step 2: Update if detection available
        if detection_centroid is not None:
            self.update(*detection_centroid)
            self.predicted_bbox = detection_bbox

            # Use corrected state
            state = self.kf.statePost
            tracked_x = int(state[0, 0])
            tracked_y = int(state[1, 0])

            # Use detection bbox dimensions but tracked position
            x, y, w, h = detection_bbox
            adj_x = tracked_x - w // 2
            adj_y = tracked_y - h // 2
            tracked_bbox = (adj_x, adj_y, w, h)

            return (tracked_x, tracked_y), tracked_bbox, False
        else:
            # No detection — use prediction only
            self.frames_lost += 1

            if self.frames_lost > self.max_lost_frames:
                # Lost track — reset
                self.initialized = False
                return None, None, False

            # Use last known bbox size for predicted box
            if self.predicted_bbox is not None:
                _, _, w, h = self.predicted_bbox
                adj_x = predicted_pos[0] - w // 2
                adj_y = predicted_pos[1] - h // 2
                pred_bbox = (adj_x, adj_y, w, h)
            else:
                pred_bbox = None

            self.track_history.append(predicted_pos)
            if len(self.track_history) > 50:
                self.track_history.pop(0)

            return predicted_pos, pred_bbox, True

    def draw_tracking(self, frame, tracked_pos, tracked_bbox, is_predicted):
        """
        Draw tracking visualisation on the frame.

        Green = active tracking (measurement available)
        Yellow = predicted (no detection, using Kalman prediction)
        """
        output = frame.copy()

        if tracked_pos is None:
            cv2.putText(output, "NO TARGET", (20, 40),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
            return output

        color = (0, 255, 255) if is_predicted else (0, 255, 0)
        status = "PREDICTED" if is_predicted else "TRACKING"

        # Draw bounding box
        if tracked_bbox is not None:
            x, y, w, h = tracked_bbox
            x, y = max(0, x), max(0, y)
            cv2.rectangle(output, (x, y), (x + w, y + h), color, 2)

        # Draw centroid crosshair
        cx, cy = tracked_pos
        cv2.drawMarker(output, (cx, cy), color,
                       cv2.MARKER_CROSS, 20, 2)

        # Draw trajectory trail
        for i in range(1, len(self.track_history)):
            pt1 = self.track_history[i - 1]
            pt2 = self.track_history[i]
            alpha = i / len(self.track_history)
            thickness = max(1, int(alpha * 3))
            trail_color = (0, int(255 * alpha), int(255 * (1 - alpha)))
            cv2.line(output, pt1, pt2, trail_color, thickness)

        # Status text
        cv2.putText(output, f"{status} | Lost: {self.frames_lost}",
                    (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        cv2.putText(output, f"Pos: ({cx}, {cy})",
                    (20, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        return output

    def reset(self):
        """Reset tracker state."""
        self.initialized = False
        self.frames_lost = 0
        self.track_history = []
        self.predicted_bbox = None
