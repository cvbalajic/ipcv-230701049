# ─── preprocessing.py ───────────────────────────────────────────────────────
# HSV + Kalman Filter Real-Time Skin Tracker — Preprocessing Pipeline
# ─────────────────────────────────────────────────────────────────────────────

import cv2
import numpy as np


def resize_image(img, width=400):
    """Resize image maintaining aspect ratio to a target width."""
    h, w = img.shape[:2]
    ratio = width / w
    new_h = int(h * ratio)
    resized = cv2.resize(img, (width, new_h), interpolation=cv2.INTER_AREA)
    return resized


def normalize_image(img):
    """Normalize pixel values to [0.0, 1.0] range."""
    return img.astype(np.float32) / 255.0


def apply_clahe(img, clip_limit=2.0, tile_size=(8, 8)):
    """
    Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
    on the L channel of LAB colour space.
    """
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_size)
    lab[:, :, 0] = clahe.apply(lab[:, :, 0])
    enhanced = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    return enhanced


def apply_gaussian_blur(img, kernel_size=(5, 5), sigma=1.5):
    """Apply Gaussian blur for denoising."""
    return cv2.GaussianBlur(img, kernel_size, sigma)


def apply_canny_edges(img, low_thresh=50, high_thresh=150):
    """Extract Canny edge map from grayscale image."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, low_thresh, high_thresh)
    return edges


def compute_histogram(img, channels=[0, 1, 2]):
    """Compute colour histogram for each specified channel."""
    histograms = {}
    color_names = {0: 'B', 1: 'G', 2: 'R'}
    for ch in channels:
        hist = cv2.calcHist([img], [ch], None, [256], [0, 256])
        histograms[color_names.get(ch, str(ch))] = hist.flatten()
    return histograms


def apply_fourier_filter(img, radius_ratio=0.30):
    """
    Apply low-pass Fourier filter to remove periodic JPEG compression
    artefacts. Only applied when Laplacian variance > 500.
    """
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    lap_var = cv2.Laplacian(gray, cv2.CV_64F).var()

    if lap_var <= 500:
        return img  # No filtering needed

    f_gray = np.float32(gray)
    dft = cv2.dft(f_gray, flags=cv2.DFT_COMPLEX_OUTPUT)
    dft_shift = np.fft.fftshift(dft)

    rows, cols = gray.shape
    crow, ccol = rows // 2, cols // 2
    radius = int(min(rows, cols) * radius_ratio)

    mask = np.zeros((rows, cols, 2), np.uint8)
    cv2.circle(mask, (ccol, crow), radius, (1, 1), thickness=-1)

    filtered = dft_shift * mask
    f_ishift = np.fft.ifftshift(filtered)
    img_back = cv2.idft(f_ishift)
    img_back = cv2.magnitude(img_back[:, :, 0], img_back[:, :, 1])
    img_back = cv2.normalize(img_back, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    # Replace luminance channel
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    lab[:, :, 0] = img_back
    result = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    return result


def full_preprocessing_pipeline(img, target_width=400):
    """
    Complete preprocessing pipeline:
    1. Resize
    2. CLAHE contrast enhancement
    3. Gaussian denoising
    4. Fourier filter (conditional)
    Returns: preprocessed BGR image, edge map, histograms (before/after CLAHE)
    """
    # Step 1: Resize
    img_resized = resize_image(img, width=target_width)

    # Histogram before CLAHE
    hist_before = compute_histogram(img_resized)

    # Step 2: CLAHE
    img_clahe = apply_clahe(img_resized)

    # Histogram after CLAHE
    hist_after = compute_histogram(img_clahe)

    # Step 3: Gaussian Blur
    img_blur = apply_gaussian_blur(img_clahe)

    # Step 4: Fourier filter (conditional)
    img_filtered = apply_fourier_filter(img_blur)

    # Step 5: Edge map (for visualization only)
    edges = apply_canny_edges(img_filtered)

    return img_filtered, edges, hist_before, hist_after


def compute_bhattacharyya_distance(hist1, hist2):
    """Compute Bhattacharyya distance between two histograms."""
    h1 = cv2.normalize(hist1, hist1).flatten().astype(np.float32)
    h2 = cv2.normalize(hist2, hist2).flatten().astype(np.float32)
    return cv2.compareHist(h1, h2, cv2.HISTCMP_BHATTACHARYYA)
