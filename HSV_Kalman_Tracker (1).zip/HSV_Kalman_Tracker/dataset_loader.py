# ─── dataset_loader.py ──────────────────────────────────────────────────────
# Pratheepan Skin Dataset Loader & Ground Truth Evaluator
# ─────────────────────────────────────────────────────────────────────────────
#
# Dataset: Pratheepan Human Skin Detection Dataset
# Source:  https://cs.aston.ac.uk/~shMDR/Pratheepan_Dataset/
#
# Structure expected:
#   dataset/
#   ├── Pratheepan/
#   │   ├── FacePhoto/          ← Original face images (JPEG/PNG)
#   │   └── GroundT_FacePhoto/  ← Ground truth binary masks
#
# ─────────────────────────────────────────────────────────────────────────────

import os
import cv2
import numpy as np
import glob


class PratheepanDataset:
    """
    Loader for the Pratheepan Skin Detection Dataset.

    The dataset contains face images with corresponding ground truth
    binary masks where white=skin and black=non-skin.
    """

    def __init__(self, dataset_root="dataset/Pratheepan"):
        """
        Args:
            dataset_root: Path to the Pratheepan folder containing
                          FacePhoto/ and GroundT_FacePhoto/
        """
        self.dataset_root = dataset_root
        self.image_dir = os.path.join(dataset_root, "FacePhoto")
        self.gt_dir = os.path.join(dataset_root, "GroundT_FacePhoto")
        self.image_paths = []
        self.gt_paths = []

        self._load_paths()

    def _load_paths(self):
        """Scan directories and pair images with ground truth masks."""
        if not os.path.exists(self.image_dir):
            print(f"[WARNING] Image directory not found: {self.image_dir}")
            print(f"[INFO] Please download the Pratheepan dataset and place it in:")
            print(f"       {self.dataset_root}/FacePhoto/")
            print(f"       {self.dataset_root}/GroundT_FacePhoto/")
            return

        # Collect all image files
        extensions = ['*.jpg', '*.jpeg', '*.png', '*.bmp']
        image_files = []
        for ext in extensions:
            image_files.extend(glob.glob(os.path.join(self.image_dir, ext)))
            image_files.extend(glob.glob(os.path.join(self.image_dir, ext.upper())))

        image_files = sorted(set(image_files))

        for img_path in image_files:
            basename = os.path.splitext(os.path.basename(img_path))[0]

            # Try to find matching ground truth
            gt_path = None
            for ext in ['.png', '.jpg', '.jpeg', '.bmp', '.PNG', '.JPG']:
                candidate = os.path.join(self.gt_dir, basename + ext)
                if os.path.exists(candidate):
                    gt_path = candidate
                    break

            if gt_path is not None:
                self.image_paths.append(img_path)
                self.gt_paths.append(gt_path)

        print(f"[INFO] Loaded {len(self.image_paths)} image-GT pairs from Pratheepan dataset.")

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        """
        Load and return an image and its ground truth mask.

        Returns:
            img: BGR image (numpy array)
            gt_mask: Binary mask (255=skin, 0=non-skin)
            img_name: Filename of the image
        """
        img = cv2.imread(self.image_paths[idx])
        gt = cv2.imread(self.gt_paths[idx], cv2.IMREAD_GRAYSCALE)

        if img is None:
            raise ValueError(f"Could not load image: {self.image_paths[idx]}")
        if gt is None:
            raise ValueError(f"Could not load GT mask: {self.gt_paths[idx]}")

        # Ensure GT is binary
        _, gt_mask = cv2.threshold(gt, 127, 255, cv2.THRESH_BINARY)

        # Resize GT to match image if dimensions differ
        if gt_mask.shape[:2] != img.shape[:2]:
            gt_mask = cv2.resize(gt_mask, (img.shape[1], img.shape[0]),
                                 interpolation=cv2.INTER_NEAREST)

        img_name = os.path.basename(self.image_paths[idx])
        return img, gt_mask, img_name

    def get_all(self):
        """Generator that yields all image-GT pairs."""
        for i in range(len(self)):
            yield self[i]


def create_sample_images(output_dir="dataset/Pratheepan"):
    """
    Create sample test images with synthetic skin-coloured regions
    when the real Pratheepan dataset is not available.
    This allows the code to run and demonstrate functionality.
    """
    face_dir = os.path.join(output_dir, "FacePhoto")
    gt_dir = os.path.join(output_dir, "GroundT_FacePhoto")
    os.makedirs(face_dir, exist_ok=True)
    os.makedirs(gt_dir, exist_ok=True)

    print("[INFO] Creating synthetic sample images for demonstration...")

    for i in range(10):
        # Create a 300x300 background image
        bg_color = np.random.randint(50, 200, 3).tolist()
        img = np.full((300, 300, 3), bg_color, dtype=np.uint8)
        gt = np.zeros((300, 300), dtype=np.uint8)

        # Add skin-coloured ellipse (face-like region)
        cx = np.random.randint(80, 220)
        cy = np.random.randint(80, 220)
        rx = np.random.randint(30, 70)
        ry = np.random.randint(40, 80)

        # Skin colour in BGR (light to medium skin tones)
        skin_colors = [
            (130, 170, 210),  # Light skin
            (100, 140, 180),  # Medium skin
            (80, 120, 160),   # Tan skin
            (60, 100, 140),   # Brown skin
            (120, 160, 200),  # Fair skin
        ]
        skin_bgr = skin_colors[i % len(skin_colors)]

        cv2.ellipse(img, (cx, cy), (rx, ry), 0, 0, 360, skin_bgr, -1)
        cv2.ellipse(gt, (cx, cy), (rx, ry), 0, 0, 360, 255, -1)

        # Add noise to make it realistic
        noise = np.random.normal(0, 10, img.shape).astype(np.int16)
        img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)

        cv2.imwrite(os.path.join(face_dir, f"sample_{i:03d}.jpg"), img)
        cv2.imwrite(os.path.join(gt_dir, f"sample_{i:03d}.png"), gt)

    print(f"[INFO] Created 10 sample images in {output_dir}")
