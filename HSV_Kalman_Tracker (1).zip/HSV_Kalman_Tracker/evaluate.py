# ─── evaluate.py ────────────────────────────────────────────────────────────
# Evaluation Module — Pixel-level and Region-level Metrics using sklearn
# ─────────────────────────────────────────────────────────────────────────────

import cv2
import numpy as np
import os
import json

from sklearn.metrics import (
    precision_score, recall_score, f1_score,
    accuracy_score, confusion_matrix, classification_report,
    jaccard_score, roc_curve, auc
)

try:
    import matplotlib
    matplotlib.use('Agg')  # Non-interactive backend
    import matplotlib.pyplot as plt
    import seaborn as sns
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

from preprocessing import full_preprocessing_pipeline
from skin_detector import detect_skin_hsv


def evaluate_on_dataset(dataset, output_dir="output", save_visuals=True):
    """
    Evaluate HSV skin detection against Pratheepan ground truth.

    Computes pixel-level metrics: Accuracy, Precision, Recall, F1, IoU
    Uses sklearn for all metric computation.

    Args:
        dataset: PratheepanDataset instance
        output_dir: Directory to save result images and plots
        save_visuals: Whether to save visualisation images

    Returns:
        results: Dictionary of computed metrics
    """
    os.makedirs(output_dir, exist_ok=True)

    all_y_true = []
    all_y_pred = []
    per_image_metrics = []

    print("\n" + "=" * 60)
    print("  HSV Skin Detection — Evaluation on Pratheepan Dataset")
    print("=" * 60)

    for idx in range(len(dataset)):
        img, gt_mask, img_name = dataset[idx]

        # ── Preprocessing ──
        preprocessed, edges, _, _ = full_preprocessing_pipeline(img, target_width=img.shape[1])

        # ── HSV Skin Detection ──
        pred_mask, skin_region = detect_skin_hsv(preprocessed)

        # Resize pred_mask to match GT if needed
        if pred_mask.shape != gt_mask.shape:
            pred_mask = cv2.resize(pred_mask, (gt_mask.shape[1], gt_mask.shape[0]),
                                   interpolation=cv2.INTER_NEAREST)

        # Flatten to 1D for sklearn
        y_true = (gt_mask.flatten() > 127).astype(np.uint8)
        y_pred = (pred_mask.flatten() > 127).astype(np.uint8)

        all_y_true.extend(y_true)
        all_y_pred.extend(y_pred)

        # Per-image metrics
        if np.sum(y_true) > 0:  # Only if GT has skin pixels
            img_acc = accuracy_score(y_true, y_pred)
            img_prec = precision_score(y_true, y_pred, zero_division=0)
            img_rec = recall_score(y_true, y_pred, zero_division=0)
            img_f1 = f1_score(y_true, y_pred, zero_division=0)
            img_iou = jaccard_score(y_true, y_pred, zero_division=0)

            per_image_metrics.append({
                'image': img_name,
                'accuracy': round(img_acc, 4),
                'precision': round(img_prec, 4),
                'recall': round(img_rec, 4),
                'f1_score': round(img_f1, 4),
                'iou': round(img_iou, 4)
            })

            print(f"  [{idx+1:3d}/{len(dataset)}] {img_name:25s} | "
                  f"Acc={img_acc:.3f} P={img_prec:.3f} R={img_rec:.3f} "
                  f"F1={img_f1:.3f} IoU={img_iou:.3f}")

        # ── Save visual comparison ──
        if save_visuals and idx < 20:  # Save first 20 images
            _save_comparison(img, gt_mask, pred_mask, skin_region,
                             edges, img_name, output_dir)

    # ── Overall Metrics (sklearn) ──
    y_true_all = np.array(all_y_true)
    y_pred_all = np.array(all_y_pred)

    overall_acc = accuracy_score(y_true_all, y_pred_all)
    overall_prec = precision_score(y_true_all, y_pred_all, zero_division=0)
    overall_rec = recall_score(y_true_all, y_pred_all, zero_division=0)
    overall_f1 = f1_score(y_true_all, y_pred_all, zero_division=0)
    overall_iou = jaccard_score(y_true_all, y_pred_all, zero_division=0)
    cm = confusion_matrix(y_true_all, y_pred_all)

    results = {
        'overall': {
            'accuracy': round(overall_acc, 4),
            'precision': round(overall_prec, 4),
            'recall': round(overall_rec, 4),
            'f1_score': round(overall_f1, 4),
            'iou': round(overall_iou, 4),
            'confusion_matrix': cm.tolist(),
            'total_images': len(dataset),
            'total_pixels': len(y_true_all)
        },
        'per_image': per_image_metrics
    }

    # ── Print Summary ──
    print("\n" + "=" * 60)
    print("  OVERALL RESULTS")
    print("=" * 60)
    print(f"  Images Evaluated : {len(dataset)}")
    print(f"  Total Pixels     : {len(y_true_all):,}")
    print(f"  Accuracy         : {overall_acc:.4f} ({overall_acc*100:.2f}%)")
    print(f"  Precision        : {overall_prec:.4f}")
    print(f"  Recall           : {overall_rec:.4f}")
    print(f"  F1-Score         : {overall_f1:.4f}")
    print(f"  IoU (Jaccard)    : {overall_iou:.4f}")
    print(f"\n  Confusion Matrix:")
    print(f"                    Predicted")
    print(f"                    Non-Skin   Skin")
    print(f"  Actual Non-Skin   {cm[0,0]:>8,}   {cm[0,1]:>8,}")
    print(f"  Actual Skin       {cm[1,0]:>8,}   {cm[1,1]:>8,}")
    print("=" * 60)

    # ── Classification Report (sklearn) ──
    report = classification_report(
        y_true_all, y_pred_all,
        target_names=['Non-Skin', 'Skin'],
        zero_division=0
    )
    print("\n  sklearn Classification Report:")
    print(report)

    # ── Save plots ──
    if HAS_MATPLOTLIB:
        _plot_confusion_matrix(cm, output_dir)
        _plot_per_image_metrics(per_image_metrics, output_dir)

    # ── Save results as JSON ──
    results_path = os.path.join(output_dir, "evaluation_results.json")
    with open(results_path, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\n  Results saved to: {results_path}")

    return results


def evaluate_preprocessing_ablation(dataset, output_dir="output"):
    """
    Ablation study: measure accuracy contribution of each preprocessing step.
    """
    print("\n" + "=" * 60)
    print("  PREPROCESSING ABLATION STUDY")
    print("=" * 60)

    configs = [
        ("No Preprocessing (Raw)", False, False, False),
        ("+ Resize Only", True, False, False),
        ("+ Resize + CLAHE", True, True, False),
        ("+ Resize + CLAHE + Gaussian", True, True, True),
    ]

    ablation_results = []

    for config_name, do_resize, do_clahe, do_blur in configs:
        all_true = []
        all_pred = []

        for idx in range(len(dataset)):
            img, gt_mask, _ = dataset[idx]
            processed = img.copy()

            if do_resize:
                h, w = processed.shape[:2]
                processed = cv2.resize(processed, (400, int(h * 400 / w)))

            if do_clahe:
                lab = cv2.cvtColor(processed, cv2.COLOR_BGR2LAB)
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                lab[:, :, 0] = clahe.apply(lab[:, :, 0])
                processed = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)

            if do_blur:
                processed = cv2.GaussianBlur(processed, (5, 5), 1.5)

            pred_mask, _ = detect_skin_hsv(processed)

            if pred_mask.shape != gt_mask.shape:
                pred_mask = cv2.resize(pred_mask, (gt_mask.shape[1], gt_mask.shape[0]),
                                       interpolation=cv2.INTER_NEAREST)

            y_true = (gt_mask.flatten() > 127).astype(np.uint8)
            y_pred = (pred_mask.flatten() > 127).astype(np.uint8)
            all_true.extend(y_true)
            all_pred.extend(y_pred)

        acc = accuracy_score(all_true, all_pred)
        prec = precision_score(all_true, all_pred, zero_division=0)
        f1 = f1_score(all_true, all_pred, zero_division=0)

        ablation_results.append({
            'config': config_name,
            'accuracy': round(acc, 4),
            'precision': round(prec, 4),
            'f1_score': round(f1, 4)
        })

        print(f"  {config_name:40s} | Acc={acc:.4f} P={prec:.4f} F1={f1:.4f}")

    return ablation_results


def _save_comparison(img, gt_mask, pred_mask, skin_region, edges,
                     img_name, output_dir):
    """Save side-by-side comparison of detection vs ground truth."""
    h, w = img.shape[:2]

    # Create comparison canvas
    gt_color = cv2.cvtColor(gt_mask, cv2.COLOR_GRAY2BGR)
    pred_color = cv2.cvtColor(pred_mask, cv2.COLOR_GRAY2BGR)
    edge_color = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

    # Resize all to same dimensions
    target_h, target_w = 200, 200
    img_r = cv2.resize(img, (target_w, target_h))
    gt_r = cv2.resize(gt_color, (target_w, target_h))
    pred_r = cv2.resize(pred_color, (target_w, target_h))
    skin_r = cv2.resize(skin_region, (target_w, target_h))

    top_row = np.hstack([img_r, gt_r])
    bot_row = np.hstack([pred_r, skin_r])
    canvas = np.vstack([top_row, bot_row])

    # Add labels
    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(canvas, "Original", (5, 15), font, 0.4, (0, 255, 0), 1)
    cv2.putText(canvas, "Ground Truth", (target_w + 5, 15), font, 0.4, (0, 255, 0), 1)
    cv2.putText(canvas, "HSV Prediction", (5, target_h + 15), font, 0.4, (0, 255, 0), 1)
    cv2.putText(canvas, "Skin Region", (target_w + 5, target_h + 15), font, 0.4, (0, 255, 0), 1)

    name_no_ext = os.path.splitext(img_name)[0]
    cv2.imwrite(os.path.join(output_dir, f"compare_{name_no_ext}.jpg"), canvas)


def _plot_confusion_matrix(cm, output_dir):
    """Plot and save confusion matrix heatmap."""
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt=',', cmap='Blues',
                xticklabels=['Non-Skin', 'Skin'],
                yticklabels=['Non-Skin', 'Skin'], ax=ax)
    ax.set_xlabel('Predicted Label')
    ax.set_ylabel('True Label')
    ax.set_title('HSV Skin Detection — Confusion Matrix')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'confusion_matrix.png'), dpi=150)
    plt.close()
    print(f"  Confusion matrix saved to: {output_dir}/confusion_matrix.png")


def _plot_per_image_metrics(metrics, output_dir):
    """Plot per-image metric bar chart."""
    if not metrics:
        return

    fig, ax = plt.subplots(figsize=(12, 5))
    names = [m['image'][:12] for m in metrics]
    f1_scores = [m['f1_score'] for m in metrics]
    iou_scores = [m['iou'] for m in metrics]

    x = np.arange(len(names))
    width = 0.35
    ax.bar(x - width / 2, f1_scores, width, label='F1-Score', color='steelblue')
    ax.bar(x + width / 2, iou_scores, width, label='IoU', color='coral')
    ax.set_xlabel('Image')
    ax.set_ylabel('Score')
    ax.set_title('Per-Image Detection Metrics')
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=45, ha='right', fontsize=7)
    ax.legend()
    ax.set_ylim(0, 1.05)
    ax.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'per_image_metrics.png'), dpi=150)
    plt.close()
    print(f"  Per-image metrics plot saved to: {output_dir}/per_image_metrics.png")
