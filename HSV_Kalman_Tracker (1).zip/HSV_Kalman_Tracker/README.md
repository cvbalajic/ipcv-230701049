# HSV + Kalman Filter Real-Time Skin Tracker

## Mini Project — Computer Vision and Image Processing

### Overview
This project implements a real-time skin detection and tracking system using:
- **HSV Colour-Space Thresholding** for skin pixel segmentation
- **Kalman Filter** for smooth, predictive tracking of skin regions
- **Pratheepan Dataset** for quantitative evaluation
- **Webcam** for real-time demonstration

### Project Structure
```
HSV_Kalman_Tracker/
├── main.py              # Main entry point (all modes)
├── skin_detector.py     # HSV skin detection module
├── kalman_tracker.py    # Kalman filter tracking module
├── preprocessing.py     # Image preprocessing pipeline
├── evaluate.py          # Evaluation with sklearn metrics
├── dataset_loader.py    # Pratheepan dataset loader
├── utils.py             # Utility functions
├── requirements.txt     # Python dependencies
├── dataset/
│   └── Pratheepan/
│       ├── FacePhoto/          # Place dataset images here
│       └── GroundT_FacePhoto/  # Place ground truth masks here
└── output/              # Generated results and screenshots
```

### Installation
```bash
pip install -r requirements.txt
```

### Usage

#### 1. Evaluate on Pratheepan Dataset
```bash
python main.py --mode dataset
```
If dataset is not present, sample images are auto-generated for demonstration.

#### 2. Real-Time Webcam Tracking
```bash
python main.py --mode webcam
```
**Controls:** q=Quit, r=Reset, s=Save, m=Mask, p=Pause, SPACE=Toggle mode

#### 3. Video File Tracking
```bash
python main.py --mode video -i path/to/video.mp4
```

#### 4. Generate Demo Screenshots
```bash
python main.py --mode demo
```

#### 5. Run Everything
```bash
python main.py --mode all
```

### Dataset
Download the Pratheepan Human Skin Detection Dataset from:
https://cs.aston.ac.uk/~shMDR/Pratheepan_Dataset/

Place images in `dataset/Pratheepan/FacePhoto/` and ground truth masks in
`dataset/Pratheepan/GroundT_FacePhoto/`.

### Libraries Used
- Python 3.9+
- OpenCV 4.8+
- NumPy
- scikit-learn (precision, recall, F1, confusion matrix, IoU)
- Matplotlib + Seaborn (visualisation)
