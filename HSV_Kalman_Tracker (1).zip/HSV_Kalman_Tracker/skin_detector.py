# ─── skin_detector.py ───────────────────────────────────────────────────────
# HSV Colour-Space Skin Detection Module
# ─────────────────────────────────────────────────────────────────────────────

import cv2
import numpy as np


# ── HSV Skin Colour Range ──
# These thresholds cover a wide range of human skin tones
HSV_LOWER = np.array([0, 30, 60], dtype=np.uint8)
HSV_UPPER = np.array([25, 170, 255], dtype=np.uint8)

# Secondary range to capture reddish skin tones near H=180
HSV_LOWER2 = np.array([160, 30, 60], dtype=np.uint8)
HSV_UPPER2 = np.array([180, 170, 255], dtype=np.uint8)


def detect_skin_hsv(img, lower1=HSV_LOWER, upper1=HSV_UPPER,
                    lower2=HSV_LOWER2, upper2=HSV_UPPER2):
    """
    Detect skin pixels using HSV colour-space thresholding.

    The method uses two HSV ranges:
      Range 1: H=[0,25], S=[30,170], V=[60,255]   — main skin tones
      Range 2: H=[160,180], S=[30,170], V=[60,255] — reddish tones

    Args:
        img: BGR input image
        lower1, upper1: Primary HSV range
        lower2, upper2: Secondary HSV range

    Returns:
        skin_mask: Binary mask (255=skin, 0=non-skin)
        skin_region: BGR image with non-skin pixels zeroed out
    """
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    # Threshold in both ranges
    mask1 = cv2.inRange(hsv, lower1, upper1)
    mask2 = cv2.inRange(hsv, lower2, upper2)
    skin_mask = cv2.bitwise_or(mask1, mask2)

    # Morphological operations to clean up the mask
    kernel_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    kernel_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11))

    # Opening: remove small noise blobs
    skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_OPEN, kernel_open, iterations=2)
    # Closing: fill small holes
    skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_CLOSE, kernel_close, iterations=2)

    # Optional: Gaussian blur to smooth mask edges
    skin_mask = cv2.GaussianBlur(skin_mask, (3, 3), 0)
    _, skin_mask = cv2.threshold(skin_mask, 127, 255, cv2.THRESH_BINARY)

    # Apply mask to original image
    skin_region = cv2.bitwise_and(img, img, mask=skin_mask)

    return skin_mask, skin_region


def find_skin_contours(skin_mask, min_area=1500):
    """
    Find contours of skin regions and filter by minimum area.

    Args:
        skin_mask: Binary skin mask
        min_area: Minimum contour area to consider (filters noise)

    Returns:
        contours: List of valid contours
        bounding_boxes: List of (x, y, w, h) bounding boxes
    """
    contours, _ = cv2.findContours(
        skin_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )

    valid_contours = []
    bounding_boxes = []

    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area >= min_area:
            x, y, w, h = cv2.boundingRect(cnt)
            aspect_ratio = float(w) / h if h > 0 else 0

            # Filter by aspect ratio (skin regions are roughly compact)
            if 0.2 < aspect_ratio < 5.0:
                valid_contours.append(cnt)
                bounding_boxes.append((x, y, w, h))

    return valid_contours, bounding_boxes


def get_largest_skin_region(skin_mask, min_area=1500):
    """
    Return the bounding box and centroid of the largest skin region.
    Used for single-target Kalman tracking.

    Returns:
        bbox: (x, y, w, h) or None if no region found
        centroid: (cx, cy) or None
    """
    contours, bboxes = find_skin_contours(skin_mask, min_area)

    if not bboxes:
        return None, None

    # Find the largest contour by area
    areas = [cv2.contourArea(c) for c in contours]
    max_idx = np.argmax(areas)

    x, y, w, h = bboxes[max_idx]
    cx = x + w // 2
    cy = y + h // 2

    return (x, y, w, h), (cx, cy)


def visualize_skin_detection(img, skin_mask, bboxes):
    """
    Draw bounding boxes and labels on the image for all detected skin regions.
    """
    output = img.copy()

    for i, (x, y, w, h) in enumerate(bboxes):
        cv2.rectangle(output, (x, y), (x + w, y + h), (0, 255, 0), 2)
        label = f"Skin #{i+1}"
        cv2.putText(output, label, (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    return output
