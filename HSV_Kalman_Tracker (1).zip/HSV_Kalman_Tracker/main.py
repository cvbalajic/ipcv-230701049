# ─── main.py ────────────────────────────────────────────────────────────────
# HSV + Kalman Filter Real-Time Skin Tracker — Main Entry Point
#
# Usage:
#   python main.py --mode webcam          # Real-time webcam tracking
#   python main.py --mode dataset         # Evaluate on Pratheepan dataset
#   python main.py --mode video -i vid.mp4 # Track in video file
#   python main.py --mode all             # Run both dataset eval + webcam
#
# Student: [Your Name] | Roll No: [XXCSEYYY] | Date: [DD-MM-YYYY]
# ─────────────────────────────────────────────────────────────────────────────

import cv2
import numpy as np
import argparse
import os
import sys
import time

from preprocessing import full_preprocessing_pipeline, apply_clahe, apply_gaussian_blur
from skin_detector import detect_skin_hsv, find_skin_contours, get_largest_skin_region
from kalman_tracker import KalmanSkinTracker
from dataset_loader import PratheepanDataset, create_sample_images
from evaluate import evaluate_on_dataset, evaluate_preprocessing_ablation
from utils import FPSCounter, create_info_panel, overlay_mask, save_frame_with_timestamp


def run_webcam_tracker(camera_id=0, save_output=True):
    """
    Run real-time HSV skin detection + Kalman filter tracking on webcam.

    Controls:
        q     — Quit
        r     — Reset tracker
        s     — Save current frame
        m     — Toggle mask overlay
        p     — Pause / Resume
        SPACE — Toggle between largest-region and all-regions mode
    """
    print("\n" + "=" * 60)
    print("  HSV + KALMAN FILTER — REAL-TIME WEBCAM TRACKER")
    print("=" * 60)
    print("  Controls:")
    print("    q = Quit | r = Reset tracker | s = Save frame")
    print("    m = Toggle mask | p = Pause | SPACE = Toggle mode")
    print("=" * 60)

    cap = cv2.VideoCapture(camera_id)
    if not cap.isOpened():
        print("[ERROR] Cannot open webcam. Trying alternative camera index...")
        cap = cv2.VideoCapture(1)
        if not cap.isOpened():
            print("[ERROR] No camera available. Exiting webcam mode.")
            return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    tracker = KalmanSkinTracker(process_noise=1e-2, measurement_noise=1e-1)
    fps_counter = FPSCounter()
    show_mask = False
    paused = False
    single_target = True  # Track largest region only
    frame_count = 0

    # Video writer for saving output
    writer = None
    if save_output:
        os.makedirs("output", exist_ok=True)
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        writer = cv2.VideoWriter('output/tracking_output.avi', fourcc,
                                 20.0, (920, 480))  # 640 + 280 info panel

    while True:
        if not paused:
            ret, frame = cap.read()
            if not ret:
                print("[INFO] End of video stream.")
                break
            frame_count += 1
        else:
            # Show paused message
            cv2.putText(frame, "PAUSED", (250, 240),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)

        fps_counter.tick()

        # ── Preprocessing ──
        preprocessed = apply_clahe(frame.copy())
        preprocessed = apply_gaussian_blur(preprocessed)

        # ── HSV Skin Detection ──
        skin_mask, skin_region = detect_skin_hsv(preprocessed)

        # ── Kalman Tracking ──
        if single_target:
            bbox, centroid = get_largest_skin_region(skin_mask, min_area=2000)
            tracked_pos, tracked_bbox, is_predicted = tracker.track(bbox, centroid)
            display = tracker.draw_tracking(frame, tracked_pos, tracked_bbox, is_predicted)
        else:
            # Multi-region mode: draw all detected regions
            contours, bboxes = find_skin_contours(skin_mask, min_area=1500)
            display = frame.copy()
            for i, (x, y, w, h) in enumerate(bboxes):
                cv2.rectangle(display, (x, y), (x + w, y + h), (0, 255, 0), 2)
                cv2.putText(display, f"Skin #{i+1}", (x, y - 8),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # ── Mask Overlay ──
        if show_mask:
            display = overlay_mask(display, skin_mask, color=(0, 255, 0), alpha=0.3)

        # ── Info Panel ──
        mode_str = "Single-Target" if single_target else "Multi-Region"
        info = {
            "FPS": fps_counter.get_fps(),
            "Frame": frame_count,
            "Mode": mode_str,
            "Skin Px": int(np.sum(skin_mask > 0)),
            "Mask": "ON" if show_mask else "OFF",
        }

        if single_target and tracked_pos is not None:
            info["Track X"] = tracked_pos[0]
            info["Track Y"] = tracked_pos[1]
            info["Lost Frm"] = tracker.frames_lost
            info["Status"] = "PRED" if is_predicted else "ACTIVE"

        display = create_info_panel(display, info)

        cv2.imshow("HSV + Kalman Skin Tracker", display)

        if writer is not None and not paused:
            writer.write(display)

        # ── Keyboard Controls ──
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('r'):
            tracker.reset()
            print("[INFO] Tracker reset.")
        elif key == ord('s'):
            path = save_frame_with_timestamp(display)
            print(f"[INFO] Frame saved: {path}")
        elif key == ord('m'):
            show_mask = not show_mask
        elif key == ord('p'):
            paused = not paused
        elif key == ord(' '):
            single_target = not single_target
            tracker.reset()
            print(f"[INFO] Mode: {'Single-Target' if single_target else 'Multi-Region'}")

    cap.release()
    if writer is not None:
        writer.release()
    cv2.destroyAllWindows()
    print("[INFO] Webcam tracker stopped.")


def run_dataset_evaluation(dataset_path="dataset/Pratheepan"):
    """
    Run evaluation on Pratheepan dataset with full metrics.
    """
    print("\n[INFO] Loading Pratheepan dataset...")
    dataset = PratheepanDataset(dataset_path)

    if len(dataset) == 0:
        print("[INFO] Dataset empty — creating sample images for demonstration...")
        create_sample_images(dataset_path)
        dataset = PratheepanDataset(dataset_path)

    if len(dataset) == 0:
        print("[ERROR] No images found. Exiting.")
        return

    # ── Full Evaluation ──
    results = evaluate_on_dataset(dataset, output_dir="output", save_visuals=True)

    # ── Ablation Study ──
    ablation = evaluate_preprocessing_ablation(dataset, output_dir="output")

    print("\n[INFO] Evaluation complete. Results saved to output/ directory.")
    return results, ablation


def run_video_tracker(video_path):
    """
    Run HSV + Kalman tracking on a video file.
    """
    if not os.path.exists(video_path):
        print(f"[ERROR] Video file not found: {video_path}")
        return

    print(f"\n[INFO] Processing video: {video_path}")

    cap = cv2.VideoCapture(video_path)
    tracker = KalmanSkinTracker()
    fps_counter = FPSCounter()
    frame_count = 0

    os.makedirs("output", exist_ok=True)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    writer = cv2.VideoWriter('output/tracked_video.avi', fourcc, fps, (w, h))

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_count += 1
        fps_counter.tick()

        # Preprocess
        preprocessed = apply_clahe(frame.copy())
        preprocessed = apply_gaussian_blur(preprocessed)

        # Detect skin
        skin_mask, _ = detect_skin_hsv(preprocessed)

        # Track largest region
        bbox, centroid = get_largest_skin_region(skin_mask)
        tracked_pos, tracked_bbox, is_predicted = tracker.track(bbox, centroid)
        display = tracker.draw_tracking(frame, tracked_pos, tracked_bbox, is_predicted)

        # FPS overlay
        cv2.putText(display, f"FPS: {fps_counter.get_fps()}", (display.shape[1] - 120, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        writer.write(display)
        cv2.imshow("Video Tracker", display)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    writer.release()
    cv2.destroyAllWindows()
    print(f"[INFO] Processed {frame_count} frames. Output: output/tracked_video.avi")


def run_image_demo(image_path=None):
    """
    Run HSV skin detection on a single image and save results.
    Used for generating report screenshots.
    """
    os.makedirs("output", exist_ok=True)

    if image_path and os.path.exists(image_path):
        img = cv2.imread(image_path)
    else:
        # Create a demo image with synthetic skin
        print("[INFO] No input image — creating demo image...")
        img = np.full((400, 400, 3), (180, 160, 140), dtype=np.uint8)
        # Draw skin-coloured ellipse
        cv2.ellipse(img, (200, 180), (60, 80), 0, 0, 360, (130, 170, 210), -1)
        cv2.ellipse(img, (200, 180), (60, 80), 0, 0, 360, (120, 160, 200), 5)
        noise = np.random.normal(0, 8, img.shape).astype(np.int16)
        img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)

    # ── Full pipeline ──
    preprocessed, edges, hist_before, hist_after = full_preprocessing_pipeline(img)
    skin_mask, skin_region = detect_skin_hsv(preprocessed)
    contours, bboxes = find_skin_contours(skin_mask)
    annotated = img.copy()
    for x, y, w, h in bboxes:
        cv2.rectangle(annotated, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # Save individual outputs
    cv2.imwrite("output/01_original.jpg", img)
    cv2.imwrite("output/02_preprocessed_clahe.jpg", preprocessed)
    cv2.imwrite("output/03_canny_edges.jpg", edges)
    cv2.imwrite("output/04_skin_mask.jpg", skin_mask)
    cv2.imwrite("output/05_skin_region.jpg", skin_region)
    cv2.imwrite("output/06_annotated_output.jpg", annotated)

    # Save histogram plot
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        for ch, color in zip(['B', 'G', 'R'], ['blue', 'green', 'red']):
            axes[0].plot(hist_before[ch], color=color, label=ch)
            axes[1].plot(hist_after[ch], color=color, label=ch)
        axes[0].set_title("Before CLAHE")
        axes[0].legend()
        axes[1].set_title("After CLAHE")
        axes[1].legend()
        plt.tight_layout()
        plt.savefig("output/07_histogram_comparison.png", dpi=150)
        plt.close()
    except ImportError:
        pass

    print("[INFO] Demo images saved to output/ directory.")


# ═══════════════════════════════════════════════════════════════════════════
#  MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="HSV + Kalman Filter Real-Time Skin Tracker"
    )
    parser.add_argument(
        "--mode", type=str, default="dataset",
        choices=["webcam", "dataset", "video", "demo", "all"],
        help="Operating mode: webcam, dataset, video, demo, or all"
    )
    parser.add_argument(
        "-i", "--input", type=str, default=None,
        help="Input video file path (for video mode)"
    )
    parser.add_argument(
        "-d", "--dataset", type=str, default="dataset/Pratheepan",
        help="Path to Pratheepan dataset root"
    )
    parser.add_argument(
        "--camera", type=int, default=0,
        help="Camera device index (default: 0)"
    )

    args = parser.parse_args()

    print("╔════════════════════════════════════════════════════════════╗")
    print("║   HSV + KALMAN FILTER REAL-TIME SKIN TRACKER             ║")
    print("║   Pratheepan Dataset / Webcam                            ║")
    print("║   Python + OpenCV + sklearn                              ║")
    print("╚════════════════════════════════════════════════════════════╝")

    if args.mode == "webcam":
        run_webcam_tracker(camera_id=args.camera)

    elif args.mode == "dataset":
        run_dataset_evaluation(dataset_path=args.dataset)

    elif args.mode == "video":
        if args.input is None:
            print("[ERROR] Video mode requires -i <video_path>")
            sys.exit(1)
        run_video_tracker(args.input)

    elif args.mode == "demo":
        run_image_demo(args.input)

    elif args.mode == "all":
        run_dataset_evaluation(dataset_path=args.dataset)
        run_image_demo()
        print("\n[INFO] Dataset evaluation and demo complete.")
        print("[INFO] Run 'python main.py --mode webcam' separately for live tracking.")
